TMCT kod odczytu API  = 

eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiJmMTA0NGQwMjdkMTc1MWZlYzcyYTNiNmQ4MTI5MjQ5YyIsIm5iZiI6MTc0ODczMDEyOC4wMDMsInN1YiI6IjY4M2I4MTBmMTQ1MzFkYzgzODI4ODc3YSIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.3RV1KwYxPYE5jaPH_b-xoxrE-3U4KJGS-BGidMZvxWQ

API=

f1044d027d1751fec72a3b6d8129249c


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     tavily 

rneNiaNPBBqv517uQXhp_bFmaUaoTdwAhx10TCwy   cloudfare

curl "https://api.cloudflare.com/client/v4/user/tokens/verify" \
     -H "Authorization: Bearer rneNiaNPBBqv517uQXhp_bFmaUaoTdwAhx10TCwy"

 "\"{\\\"githubPersonalAccessToken\\\":\\\"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 \\\"}\"

 "BRAVE_API_KEY": "BSAa8VqK4CjkKCwCNtTqlCDMcLLDvWD"

  "AGENTQL_API_KEY": "PnDuagKfL8oY5ZEu7aSP4JKqQya_uWGx7ZwIux5N_D7rtUY8Z9aNIw"

  "WEBSCRAPING_AI_API_KEY": "fdd92a5e-8b0e-4d74-80c3-7233bad8d812",
        "WEBSCRAPING_AI_CONCURRENCY_LIMIT": "5"

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
openai

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 hugingface 09.01.2025
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   - hugingface mybonzo2 z wszystkimi mozliwosciami 01/wrzesnia/2025

sk-ece3dae62ba14a798c8d4c069a30553d  webui

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   - antropic  my bonzo


f33e752a48msh592929a11875a3ap19fa35jsn5ac7f5afc267      X-RapidAPI

WEATHER_API_KEY=67a0b73aa29134cdee57d717501b2327  wheater

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               hugingface

AIzaSyB9NCtIYE6ChhiR00dFcQuJjUoyxxeNQWA  grminni         set GOOGLE_API_KEY="AIzaSyB9NCtIYE6ChhiR00dFcQuJjUoyxxeNQWA"


