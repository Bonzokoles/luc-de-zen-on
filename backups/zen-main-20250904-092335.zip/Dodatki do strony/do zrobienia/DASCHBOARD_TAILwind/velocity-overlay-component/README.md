# Velocity.js  fullscreen flexbox overlay navigation

A Pen created on CodePen.

Original URL: [https://codepen.io/fluxus/pen/gPWvZm](https://codepen.io/fluxus/pen/gPWvZm).

Another take on my flexbox fullscreen overlay navigation. Spicing things up with a bit of Velocity.js