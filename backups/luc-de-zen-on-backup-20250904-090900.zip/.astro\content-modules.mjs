
export default new Map([
["src/posts/agent-demo.mdx", () => import("astro:content-layer-deferred-module?astro%3Acontent-layer-deferred-module=&fileName=src%2Fposts%2Fagent-demo.mdx&astroContentModuleFlag=true")],
["src/posts/using-mdx.mdx", () => import("astro:content-layer-deferred-module?astro%3Acontent-layer-deferred-module=&fileName=src%2Fposts%2Fusing-mdx.mdx&astroContentModuleFlag=true")]]);
		