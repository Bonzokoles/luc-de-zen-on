---
title: "Markdown Style Guide"
published: true
description: "Here is a sample of some basic Markdown syntax that can be used when writing Markdown content."
tags: ["Tag A", "Tag C", "Tag E"]
date: "Jun 19 2024"
---
